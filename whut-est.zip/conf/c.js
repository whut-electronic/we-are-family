var c = [{
    url : "/img/about-me.jpg",
    title : "干部培训",
    introduce:"电子科技协会干部培训工作",
    res : "1",
    auther : "余阳",
    time:"2019-03-03",
    num : "45"
}];

module.exports = c;