var b = [{
    year  : 2018,
    res : 1,
    url : "/img/b/2018.png"
},
    {
        year  : 2017,
        res : 2,
        url : "/img/b/2017.jpg"
    }];
module.exports = b;